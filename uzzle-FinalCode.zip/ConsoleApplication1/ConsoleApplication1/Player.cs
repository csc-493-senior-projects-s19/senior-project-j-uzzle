﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ConsoleApplication1
{
    [Serializable()]
    public class Player
    {
        private int energy;
        private int state;
        public int roomID;
        private Room currentRoom;
        public Player()
        {
            /*To add:*List of items in the inventory, list of equipped items,* link to the current room, 
             *  integer representing current energy, id of the current room, 
             *  *item representing the equipped item, item representing the wielded item*
             *  THIS CLASS -MUST- BE SERIALIZABLE 
             */
            energy = 0;
            state = 0;
            currentRoom = null;
            roomID = 0;
    }
        public int GetState()
        {
            ///o	Pre: the user has a value for the state
            ///o	Post: returns the string value for the user’s state
            return state;
        }
        public void SetState(int s)
        {
            ///o Pre: s is a string, and the player has a value for the state.
            ///o   Post: sets the state for the user to value s
            state = s;
        }
        public Room GetRoom()
        {
            ///o	Pre: the player is in a room
            ///o Post: returns a link to the room object that the player is in
            return currentRoom;
        }
        public void SetRoom(Room r)
        {
            ///o	Pre: the player exists. The player does not have to be in a room. 
            /// Room r is a link to a room with at least 1 door
            /// o	Post: sets the current room of the player to room r
            currentRoom = r;
            roomID = r.GetUniqueId();
        }
        /*To add:
         -	Equip(position):
o	Pre: position is an integer between zero and the length of the player’s inventory minus 1
o	Post: equips the item at position in the player’s inventory. Returns the equipped item to the client
-	Wield()
o	Pre: the equipped item is not a null pointer
o	Post: sets the equipped item to the wielded item
-	EquippedItem()
o	Pre: the equipped item is not a null pointer
o	Post: returns a link to the equipped item
-	WieldedItem()
o	Pre: the wielded item is not a null pointer
o	Post: returns the wielded item
*/	
public void ChangeEnergy(int amount) {
            ///Pre: amount is an integer
            ///Post: increments or decrements the amount of energy the player has 
            this.energy += amount;
        }

        public void SetEnergy(int amount) {
            ///Pre: amount is positive integer
            ///	Post: sets the amount of energy the player has to amount
            this.energy = amount;
        }
            public int GetEnergy() {
            ///o	Pre: the player has been instantiated
            ///o	Post: returns the user’s current energy in the form of an integer
            return this.energy;
}/*
-	GetInventory()
o	Pre: the player has an inventory list
o	Post: returns a mutable list of items contained in the player’s inventory
*/
    }
}
