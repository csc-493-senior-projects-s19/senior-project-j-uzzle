﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;

namespace ConsoleApplication1
{
    class Program
    {
        private void test1()
        {
            //testing basic player and room classes
            Player play = new Player();
            Room r = new Room(420);
            r.SetTypeID(0);
            play.SetRoom(r);
            System.Console.Write(play.GetRoom().GetUniqueId());
            play.GetRoom().SetTypeID(1);
            Door dr = new Door();
            dr.AddDescriptor(2);
            System.Console.Write("\n");
            System.Console.Write(dr.GetDescriptors()[1]);
            Door dr2 = new Door();
            r.AddDoor(dr2);
            System.Console.Write(r.GetDoor(0).GetDescriptors()[0]);
        }
        private void test2()
        {
            //XmlSerializer writer = new XmlSerializer(typeof(List<int[]>));
            //List<int[]> data = new List<int[]>();
            //data.Add(new int[2] {0,1});
            var path = Environment.CurrentDirectory + "//datafile.xml";
            //FileStream file = File.Create(path);
            //writer.Serialize(file, data);
            XmlSerializer reader = new XmlSerializer(typeof(List<int[]>));
            StreamReader readfile = new StreamReader(path);
            List<int[]> data = (List<int[]>)reader.Deserialize(readfile);

            readfile.Close();
            Console.WriteLine("");
            for (int i = 0; i < data.Count; i++)
            {
                Console.WriteLine(data[i][0]);
                Console.WriteLine(data[i][1]);
            }
            //Looking at the current location for the executed assembly
            Console.WriteLine(System.Reflection.Assembly.GetExecutingAssembly().Location);
        }

        private void test3()
        {
            //XmlSerializer writer = new XmlSerializer(typeof(List<string>));
            XmlSerializer reader = new XmlSerializer(typeof(List<string>));
            //List<string> data = new List<string>();
            //data.Add("null");
            var path = Environment.CurrentDirectory + "//descmap.xml";
            //FileStream file = File.Create(path);
            StreamReader readfile = new StreamReader(path);
            //writer.Serialize(file, data);
            List<string> data = (List<string>)reader.Deserialize(readfile);

            
        }
        
        static void Main(string[] args)
        {
            Program p = new Program();
            //p.test1();
            //p.test2();
            p.test3();
            System.Console.ReadKey();
        }
    }
}
