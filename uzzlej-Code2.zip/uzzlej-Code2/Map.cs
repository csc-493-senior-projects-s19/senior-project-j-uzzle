﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;


namespace ConsoleApplication1
{
    class Map
    {
        Room root;
        byte maxdoors, maxlevel, mindoors, minlevel;
        ushort maxrooms, minrooms;
        ushort portalchance, maptype;
        List<Room> roomtypes;
        List<uint> roomchances;
        List<Room> rooms;
        public Map()
        {
            /*o	Pre: the map doesn’t exist yet.
o	Post: creates a map with a root room of null
o	Variables: Max doors each room may have, max level the map may go to, the minimum number of doors each room may 
have (excluding dead-ends, which must always be able to appear), the minimum number of levels that the map may have,
the maximum number of rooms the map may have, the minimum number of rooms the map may have (supersedes the minimum 
number of levels), hasPortals that represents whether or not the map has portal doors, List with links to all rooms 
in the map
The  maximum number of levels will take precedence over the minimum number of rooms. The minumum
number of levels will take precedence over the maximum number of rooms. If the minimum 
number of rooms is greater than the number of levels that can hold that, it will stop adding rooms.
If the maximum  room number is less than the amount in the minimum number of levels, it will keep adding
rooms until the minimum number of levels is filled out.
Portal chance will be the chance out of 10,000 that a room will have a portal if it does not have the maximum
number of doors.
*/
            root = new Room(0);
            maxdoors = 2;
            mindoors = 1;
            maxlevel = 8;
            minlevel = 3;
            maxrooms = 100;
            minrooms = 30;
            portalchance = 25;
            maptype = 0;
            rooms = new List<Room>();
            rooms.Add(root);
            //Each slot in roomchances corresponds to the TypeID of the corresponding room type
            roomchances = new List<uint>();
            
        }
        private Room GetRoomType(string roomfile, string chancefile, uint index)
        {
            /*Pre: roomfile is the file name of a serialized list of rooms without any links to other rooms.
             * chancefile is a file name of a serialized list of nonzero unsigned integers with the frequency of each room 
             * in the corresponding room file being represented at that position in the chance file.
             * Both the chancefile and roomfile must represent lists with an equal count.
             *
             * The index is an unsigned integer between 0 and the sum of all entries in the chance file list.
             Post: returns the room at that index in the deserialized list. Returns null  if the index is greater
             than the count of the list itself.*/
            var roompath = Environment.CurrentDirectory + "//"+roomfile;
            var chancepath = Environment.CurrentDirectory + "//" + chancefile;

            XmlSerializer roomreader = new XmlSerializer(typeof(List<Room>));
            StreamReader roomreadfile = new StreamReader(roompath);
            List<Room> roomdata = (List<Room>)roomreader.Deserialize(roomreadfile);
            roomreadfile.Close();
            XmlSerializer chancereader = new XmlSerializer(typeof(List<uint>));
            StreamReader chancereadfile = new StreamReader(chancepath);
            List<uint> chancedata = (List<uint>)roomreader.Deserialize(chancereadfile);
            chancereadfile.Close();
            //Run through the chance list
            uint sum = 0;
            for (int i = 0; i < chancedata.Count; i++)
            {
                //Compute the sum of this value with all previous chances
                sum = sum + chancedata[i];
                //If the index we are looking for is below or equal to the current sum
                //that means that the index was greater than the previous sum values, and
                //thus outside the range of those values.
                if (index <= sum)
                {
                    return roomdata[i];
                }
            }
            return null;
        }
        public void AddRoom(Room r)
            {
            rooms.Add(r);
        }
        public Room GetRoom(int i)
        {
            return rooms[i];
        }
        
    }
}
