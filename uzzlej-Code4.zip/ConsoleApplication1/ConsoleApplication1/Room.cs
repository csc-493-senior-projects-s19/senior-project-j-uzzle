﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;


namespace ConsoleApplication1
{
    [Serializable()]
    public class Room
    {
        public int UID;
        public int TypeID;
        private List<int> descriptors;
        [NonSerialized()] private List<Room> rooms;
        public List<int> roomIDs;
        [NonSerialized()] private List<Door> doors;
        public List<int> doorIDs;
        public int level;
        public Room()
        {
            ///	o	List of all possible events each in a tuple with its possibility of occurring, list of descriptors,
            ///	id number, list of rooms that this room 
            ///	has doors leading to in tuples with links to their corresponding doors
            ///	--THIS CLASS MUST BE SERIALIZABLE--
            descriptors = new List<int>();
            rooms = new List<Room>();
            doors = new List<Door>();
            //List of room and door ids in order from left to right
            doorIDs = new List<int>();
            roomIDs = new List<int>();
        }
        public Room(int id)
        {
            ///	o	List of all possible events each in a tuple with its possibility of occurring, list of descriptors,
            ///	id number, list of rooms that this room 
            ///	has doors leading to in tuples with links to their corresponding doors
            ///	--THIS CLASS MUST BE SERIALIZABLE--
            descriptors = new List<int>();
            rooms = new List<Room>();
            doors = new List<Door>();
            UID = id;
        }
        public List<int> GetDescriptors()
        {
            ///  Pre: this room has a list of descriptors
            ///  Post: returns a list of descriptors describing different aspects of the room
            return descriptors;
        }
        public void AddDescriptor(int desc)
        {
            ///	Pre: this door has a list of descriptors. This does not have to be empty. Desc is a descriptor
            /// Post: adds desc to the list of descriptors
            descriptors.Add(desc);
        }
        public void RemoveDescriptor(int desc)
        {
            /// Pre: this room has a list of descriptors that is not empty, desc is a descriptor.
            /// Post: removes descriptor desc from the list of descriptors for this room\
            descriptors.Remove(desc);
        }
        public void ClearDescriptors()
        {
            ///Pre: this room has a list of descriptors
            ///Post: removes all descriptors from this object
            descriptors.Clear();
        }
        public int GetUniqueId()
        {
            ///Pre: this room has a unique ID
            ///Post: returns this room's unique ID
            return UID;
        }
        public void SetUniqueID(int id)
        {
            ///Pre: this room exists inside a map
            ///Post: sets the unique id to id
            UID = id;
        }
        public int GetTypeId()
        {
            ///Pre: this room has a unique ID
            ///Post: returns this room's unique ID
            return TypeID;
        }
        public void SetTypeID(int id)
        {
            ///Pre: this room exists inside a map
            ///Post: sets the unique id to id
            TypeID = id;
        }
        public void AddRoom(Room rm, Door dr)
        {
            /*
    o Pre: rm is a room-type object and dr is a door-type object
    o   Post: Adds a rm and dr to the to the list of rooms and doors available for this room*/
            rooms.Add(rm);
            roomIDs.Add(rm.GetUniqueId());
            doors.Add(dr);
        }
        public void AddRoom(Room rm)
        {
            /*
    o Pre: rm is a room-type object
    o   Post: Adds a rm to the to the list of rooms available for this room*/
            rooms.Add(rm);
        }

        public void AddDoor(Door dr)
        {
            /*
    o Pre:  dr is a door-type object
    o   Post: Adds dr to the to the list of  doors available for this room*/
            doors.Add(dr);
        }
    

        public Room GetRoom(int index) {
            /*
o Pre: index is a positive integer less than the length of this room’s list of rooms
o Post: returns a reference to the room at position index
returns null if the index is out of bounds*/
            if (index < rooms.Count)
            {
                return rooms[index];
            }
            else
            {
                return null;
            }
        }
    public Door GetDoor(int index) {/*
            o Pre: index is a positive integer less than the length of this room’s list of rooms
            o Post: returns a reference to the door at position index*/
            if (index < doors.Count)
            {
                return doors[index];
            }
            else
            {
                return null;
            }
        }
        public int NumDoors()
        {
            ///Returns the number of doors this room has links to
            return doors.Count;
        }
        public void AddRoomID(int id)
        {
            roomIDs.Add(id);
        }
        public void AddDoorID(int id)
        {
            doorIDs.Add(id);
        }
        public void SetLevel(int lvl)
        {
            level = lvl;
        }
        public int GetLevel()
        {
            return level;
        }
        /*-
-	
-	AddEvent(ev,ch)
o	Pre: ev is an event-type object, ch is a floating-point number.
o	Post: Adds a event ev to this room’s event list, and ch to the list of chances.
-	GetRandEvent()
o	Pre: the event list for this object is not empty, and each tuple in it has a second value greater than 0
o	Post: returns an event object chosen at random from this room’s event list
*/
    }
}
